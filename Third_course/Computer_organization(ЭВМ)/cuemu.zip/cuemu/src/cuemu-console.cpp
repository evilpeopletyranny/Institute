#include <cstdio>
#include <cstdlib>
#include "cuemu.h"

// ���������� ������� cuemu
int main()
{
 cout << "CUEMU - simple control unit emulator\n";
 cout << "Powered by Borland C++ 5.02\n";
 cout << "Copyright (C) Vigura Anton (2006)\n";
 process_stream(cin, true);
 if (list) clear(list);
 if (connections) clear(connections);
 return EXIT_SUCCESS;
}
